// Client-side D3 (v7) rendering for the interactive lago_report() HTML report.
//
// This file is self-contained: it depends only on the vendored D3 v7 library
// (inst/js/d3.v7.min.js) and never touches Shiny, jQuery, or any external CDN,
// so the rendered report stays a single, offline, shareable HTML file. It is a
// SEPARATE file from inst/js/cost-curves.js (the Shiny cost visualizer); the
// small polynomial-cost math below is COPIED from there on purpose so the two
// stay independent and cost-curves.js can keep its Shiny wiring untouched.
//
// The file is split into two parts, mirroring cost-curves.js:
//   1. Pure math (costAt / marginalAt / sampleCurve). No DOM/d3 dependency, so
//      it can be unit-tested under node (tests/js/test-report-math.js).
//   2. Browser rendering, exposed as window.LAGOReport with these entry points:
//        LAGOReport.renderConfidenceSet(elementId, data)
//        LAGOReport.renderCostCurves(elementId, data)
//        LAGOReport.renderSensitivity(elementId, data)  (used by the playground)
//        LAGOReport.renderBudget(elementId, data)        (used by the playground)
//      Each takes the JSON the report serialized with jsonlite and a target
//      element id, and draws into that element. They are no-ops when d3 is
//      absent, so the report degrades gracefully.

(function (global) {
  "use strict";

  // ------------------------------------------------------------------
  // 1. Pure math (mirrors R's calculate_cost / calculate_derivative).
  //    Copied from cost-curves.js so this file has no dependency on it.
  // ------------------------------------------------------------------

  // Total cost at x: sum_k coef[k] * x^k, via Horner's method.
  function costAt(coefs, x) {
    var acc = 0;
    for (var k = coefs.length - 1; k >= 0; k--) {
      acc = acc * x + coefs[k];
    }
    return acc;
  }

  // Marginal cost (first derivative) at x: sum_k k * coef[k] * x^(k-1).
  function marginalAt(coefs, x) {
    var n = coefs.length;
    if (n <= 1) {
      return 0;
    }
    var acc = 0;
    for (var k = n - 1; k >= 1; k--) {
      acc = acc * x + coefs[k] * k;
    }
    return acc;
  }

  // Sample fn evenly over [lb, ub] into {x, y} points.
  function sampleCurve(coefs, lb, ub, n, fn) {
    var pts = [];
    var step = (ub - lb) / (n - 1);
    for (var i = 0; i < n; i++) {
      var x = i === n - 1 ? ub : lb + i * step;
      pts.push({ x: x, y: fn(coefs, x) });
    }
    return pts;
  }

  // Sensitivity points that can be plotted: both value and cost present and
  // finite. A failed run serializes cost as null, and +null is 0 (finite), so
  // the null check must come first. Pure so it can be unit-tested.
  function sensFinitePoints(points) {
    return (points || []).filter(function (p) {
      return p && p.value != null && p.cost != null &&
        isFinite(+p.value) && isFinite(+p.cost);
    });
  }

  // Budget-frontier points that can be plotted: both recommended cost and
  // estimated outcome present and finite (a null from R must be rejected before
  // the finite check, since +null is 0). Pure so it can be unit-tested.
  function budgetFinitePoints(frontier) {
    return (frontier || []).filter(function (p) {
      return p && p.rec_int_cost != null && p.est_outcome != null &&
        isFinite(+p.rec_int_cost) && isFinite(+p.est_outcome);
    });
  }

  // The decimal digits of a finite, nonzero number, as 15 significant digits
  // (all a double holds without noise), with the sign and the power of 10 of
  // the first digit, the way R's .lago_dec_digits() gets them from sprintf().
  // It also gives the digits roundDec() rounds from, as cutDigits (17 of
  // them) with the power of 10 cutExp: the 15 digits followed by 00 when they
  // read back as the same double, so a typed value such as 2.30495 is rounded
  // as 2.30495, and the 17 digits otherwise, so a value such as
  // 404461827.45464969 is not rounded twice.
  function decDigits(v) {
    var a = Math.abs(v);
    // 17 significant digits, rounded to 15 the way R's .lago_dec_digits()
    // does: 50 in the 16th and 17th digits goes to even, more goes up
    var s = a.toExponential(16);
    var all = s.charAt(0) + s.slice(2, 18);
    var exp = parseInt(s.slice(19), 10);
    var head = all.slice(0, 15);
    var rest = all.slice(15, 17);
    var up = rest > "50" || (rest === "50" && +head.charAt(14) % 2 === 1);
    var kept = +head + (up ? 1 : 0);
    if (kept >= 1e15) {
      kept = kept / 10;
      exp += 1;
    }
    var digits = String(kept);
    var same = Number(digits + "e" + (exp - 14)) === a;
    return {
      neg: v < 0,
      digits: digits,
      exp: exp,
      cutDigits: same ? digits + "00" : all,
      cutExp: same ? exp : parseInt(s.slice(19), 10)
    };
  }

  // v rounded to n significant digits (sig true) or to n decimals (sig false),
  // at most 15 significant digits, with a cut digit of 5 rounded up, away from
  // 0, as R's .lago_round_dec() does. It rounds in one step from the
  // cutDigits of decDigits(), so 404461827.45464969 gives
  // 404461827.4546 at 4 decimals, not 404461827.4547. toFixed() and
  // toPrecision() settle a cut digit of 5 by the binary value instead, so
  // 0.10005 and 12.3455 would round differently from the R text of the report.
  function roundDec(v, n, sig) {
    v = +v;
    if (!isFinite(v) || v === 0) {
      return v;
    }
    var p = decDigits(v);
    var keep = Math.min(sig ? n : n + p.cutExp + 1, 15);
    var next = keep >= 0 ? +p.cutDigits.charAt(keep) : 0;
    var kept = keep > 0 ? +p.cutDigits.slice(0, keep) : 0;
    if (next >= 5) {
      kept += 1;
    }
    var r = Number((p.neg ? "-" : "") + kept + "e" + (p.cutExp + 1 - keep));
    // a value rounded to 0 is 0, not -0
    return r === 0 ? 0 : r;
  }

  // Write a rounded number the way R's .lago_num_text() writes it in the
  // report text: in full from 1e-6 up to 1e21, and in e notation such as 1e-7
  // and 1.5e+21 outside that range, with at most 15 significant digits.
  function numText(v) {
    v = +v;
    if (!isFinite(v)) {
      return String(v);
    }
    if (v === 0) {
      return "0";
    }
    var p = decDigits(v);
    var d = p.digits.replace(/0+$/, "");
    var k = d.length;
    var e = p.exp;
    var out;
    if (e < -6 || e > 20) {
      out = (k > 1 ? d.charAt(0) + "." + d.slice(1) : d) + "e" + (e >= 0 ? "+" : "-") + Math.abs(e);
    } else if (e >= k - 1) {
      out = d + new Array(e - k + 2).join("0");
    } else if (e < 0) {
      out = "0." + new Array(-e).join("0") + d;
    } else {
      out = d.slice(0, e + 1) + "." + d.slice(e + 1);
    }
    return (p.neg ? "-" : "") + out;
  }

  // A component value, rounded like R's .lago_fmt_value(): 4 decimals, or 4
  // significant digits for values closer to 0 than 0.1 (values closer to 0
  // than 1e-6 keep 4 decimals, so they show as 0).
  function fmtValue(v) {
    v = +v;
    var a = Math.abs(v);
    return numText(a >= 0.1 || a < 1e-6 || !isFinite(v) ? roundDec(v, 4, false) : roundDec(v, 4, true));
  }

  // An estimated outcome or a CI bound, rounded like R's
  // .lago_fmt_interval(): 3 decimals, or 4 significant digits below 0.1.
  function roundInterval(v) {
    v = +v;
    return Math.abs(v) >= 0.1 || !isFinite(v) ? roundDec(v, 3, false) : roundDec(v, 4, true);
  }

  function fmtInterval(v) {
    return numText(roundInterval(v));
  }

  // An estimated outcome next to the goal it reached, like R's
  // .lago_fmt_estimate(). It is rounded with fmtInterval(), but when the goal
  // was reached (reached is true) and the rounded estimate is on the missed
  // side of the rounded goal (below it for "maximize", above it for
  // "minimize") while the estimate is within 1e-5 times max(1, |goal|) of the
  // goal, it shows as the rounded goal. The optimizer meets a goal up to a
  // small tolerance, so an estimate a hair short of a goal of 0.8125 would
  // show as 0.812 next to a goal shown as 0.813.
  function fmtEstimate(est, goal, intention, reached) {
    var e = roundInterval(est);
    if (reached === true && goal != null && isFinite(+goal) && isFinite(e) &&
      Math.abs(+est - +goal) <= 1e-5 * Math.max(1, Math.abs(+goal))) {
      var g = roundInterval(goal);
      if ((intention === "maximize" && e < g) || (intention === "minimize" && e > g)) {
        e = g;
      }
    }
    return numText(e);
  }

  // A cost, rounded like R's .lago_fmt_cost(): 5 significant figures, or 2
  // decimals from 1e4 up, so a large fixed cost does not hide the part that
  // changes with the dose.
  function roundCost(v) {
    v = +v;
    return isFinite(v) && Math.abs(v) >= 1e4 ? roundDec(v, 2, false) : roundDec(v, 5, true);
  }

  function fmtCost(v) {
    return numText(roundCost(v));
  }

  // A cost rounded like fmtCost(), but never above a budget it fits in, like
  // R's .lago_fmt_cost_within(). A cost just under the budget can round up
  // past it, and it then shows one unit of its last digit lower, which is the
  // cost rounded down to the same digits.
  function fmtCostWithin(v, budget) {
    v = +v;
    var r = roundCost(v);
    if (budget != null && isFinite(+budget) && isFinite(v) && v > 0 && v <= +budget && r > +budget) {
      var unit = v >= 1e4 ? 0.01 : Math.pow(10, Math.floor(Math.log10(v)) - 4);
      r = roundCost(r - unit);
    }
    return numText(r);
  }

  var math = {
    decDigits: decDigits,
    roundDec: roundDec,
    numText: numText,
    fmtValue: fmtValue,
    fmtInterval: fmtInterval,
    fmtEstimate: fmtEstimate,
    fmtCost: fmtCost,
    fmtCostWithin: fmtCostWithin,
    costAt: costAt,
    marginalAt: marginalAt,
    sampleCurve: sampleCurve,
    sensFinitePoints: sensFinitePoints,
    budgetFinitePoints: budgetFinitePoints,
    sensTooltipLines: sensTooltipLines
  };

  // Export for node (unit tests). Harmless in the browser.
  if (typeof module !== "undefined" && module.exports) {
    module.exports = math;
  }
  // Also expose on the global for browser debugging / reuse.
  if (global) {
    global.LAGOReportMath = math;
  }

  // ------------------------------------------------------------------
  // 2. Browser rendering (skipped under node, where d3 is undefined).
  // ------------------------------------------------------------------
  if (typeof d3 === "undefined") {
    // Still expose stub entry points so a caller never throws; they no-op.
    if (global) {
      global.LAGOReport = {
        renderConfidenceSet: function () {},
        renderCostCurves: function () {},
        renderSensitivity: function () {},
        renderBudget: function () {}
      };
    }
    return;
  }

  // Fixed internal coordinate system. Every <svg> is sized to 100% width with a
  // viewBox so it scales with the page and never measures zero.
  var W = 640;
  var H = 380;
  var MARGIN = { top: 34, right: 24, bottom: 46, left: 66 };
  var IW = W - MARGIN.left - MARGIN.right;
  var IH = H - MARGIN.top - MARGIN.bottom;

  var COLOR_POINT = "#0066cc"; // grid interventions in the confidence set
  var COLOR_REC = "#cc3300"; // recommended intervention (matches plot.lago)
  var COLOR_TOTAL = "#0066cc"; // total-cost curve
  var COLOR_MARGINAL = "#cc3300"; // marginal-cost curve

  // Create a titled, axed SVG inside `sel` and return the plot group plus the
  // scales. Shared by the confidence-set and cost-curve charts.
  function makeSvg(sel, opts) {
    var svg = sel
      .append("svg")
      .attr("viewBox", "0 0 " + W + " " + H)
      .attr("width", "100%")
      .attr("preserveAspectRatio", "xMidYMid meet")
      .style("font-family", "sans-serif")
      .style("overflow", "visible")
      .style("max-width", "760px")
      .style("display", "block");

    var g = svg
      .append("g")
      .attr("transform", "translate(" + MARGIN.left + "," + MARGIN.top + ")");

    // axes
    g.append("g")
      .attr("transform", "translate(0," + IH + ")")
      .call(d3.axisBottom(opts.xScale).ticks(6))
      .selectAll("text")
      .style("font-size", "11px");
    if (opts.yScale) {
      g.append("g")
        .call(d3.axisLeft(opts.yScale).ticks(6))
        .selectAll("text")
        .style("font-size", "11px");
    }

    // axis titles
    g.append("text")
      .attr("x", IW / 2)
      .attr("y", IH + 38)
      .attr("text-anchor", "middle")
      .style("font-size", "12px")
      .text(opts.xlab);
    if (opts.ylab) {
      g.append("text")
        .attr("transform", "rotate(-90)")
        .attr("x", -IH / 2)
        .attr("y", -MARGIN.left + 16)
        .attr("text-anchor", "middle")
        .style("font-size", "12px")
        .text(opts.ylab);
    }

    // plot title
    svg
      .append("text")
      .attr("x", MARGIN.left)
      .attr("y", 18)
      .style("font-size", "13px")
      .style("font-weight", "600")
      .text(opts.title);

    return { svg: svg, g: g };
  }

  // A reusable SVG tooltip group that follows a point and word-wraps its lines.
  // Returns { show(lines, px, py), hide() }. `lines` is an array of strings.
  function makeTooltip(g) {
    var tip = g.append("g").style("display", "none").style("pointer-events", "none");
    var rect = tip
      .append("rect")
      .attr("fill", "white")
      .attr("stroke", "#ccc")
      .attr("rx", 3)
      .attr("opacity", 0.96);
    var text = tip.append("text").attr("x", 6).attr("y", 14).style("font-size", "11px");

    function show(lines, px, py) {
      text.selectAll("tspan").remove();
      lines.forEach(function (ln, i) {
        text
          .append("tspan")
          .attr("x", 6)
          .attr("dy", i === 0 ? 0 : 14)
          .text(ln);
      });
      var bb = text.node().getBBox();
      rect.attr("width", bb.width + 12).attr("height", bb.height + 8);
      // keep the tooltip inside the plot box
      var tx = px + 10 + bb.width + 12 > IW ? px - bb.width - 22 : px + 10;
      var ty = Math.min(Math.max(0, py - 10), IH - bb.height - 8);
      tip.attr("transform", "translate(" + tx + "," + ty + ")").style("display", null);
      tip.raise();
    }

    function hide() {
      tip.style("display", "none");
    }

    return { show: show, hide: hide };
  }

  // Nice numeric [min, max] padded by `frac`, always finite and non-degenerate.
  function paddedExtent(values, frac) {
    var lo = d3.min(values);
    var hi = d3.max(values);
    if (!isFinite(lo) || !isFinite(hi)) {
      return [0, 1];
    }
    if (lo === hi) {
      var d = Math.abs(lo) > 0 ? Math.abs(lo) * 0.1 : 1;
      return [lo - d, hi + d];
    }
    var pad = (hi - lo) * (frac == null ? 0.06 : frac);
    return [lo - pad, hi + pad];
  }

  // ---- confidence-set viz -------------------------------------------------
  //
  // data.components : column names in data.cs that hold the intervention
  //                   components (1 or 2 of them, matching rec_int).
  // data.cs         : array of row objects, one per grid intervention in the
  //                   confidence set. Each has the component columns plus
  //                   CI_lower_bound, CI_upper_bound, and cost.
  // data.rec_int    : the recommended intervention, one value per component.
  // data.confidence_level : the level label, such as "95%".
  //
  // Two components -> scatter of the two components with the recommended point
  // highlighted. One component -> a 1-D strip (number line) of the doses. 3+
  // components are handled by the R fallback (static plot), so this no-ops.
  function renderConfidenceSet(elementId, data) {
    var host = document.getElementById(elementId);
    if (!host || !data || !data.cs || !data.components) {
      return;
    }
    var comps = data.components;
    var cs = data.cs;
    // the level the result was computed at, such as "95%"
    level = data.confidence_level || "95%";
    var rec = data.rec_int || [];
    var sel = d3.select(host);
    sel.selectAll("*").remove();

    if (comps.length === 2) {
      renderCsScatter(sel, comps, cs, rec, data.rec_int_cost);
    } else if (comps.length === 1) {
      renderCsStrip(sel, comps, cs, rec, data.rec_int_cost);
    }
    // 3+ components: intentionally nothing (R renders the static fallback).
  }

  // the confidence level of the rendered result, set by the render call
  var level = "95%";

  // Format the shared tooltip lines for one confidence-set row.
  function csTooltipLines(comps, row) {
    var lines = comps.map(function (c) {
      return c + ": " + fmtValue(row[c]);
    });
    if (row.cost != null && isFinite(row.cost)) {
      lines.push("cost: " + fmtCost(row.cost));
    }
    if (row.CI_lower_bound != null && row.CI_upper_bound != null) {
      lines.push(level + " CI: " + fmtInterval(row.CI_lower_bound) + " - " + fmtInterval(row.CI_upper_bound));
    }
    return lines;
  }

  function renderCsScatter(sel, comps, cs, rec, recCost) {
    var xKey = comps[0];
    var yKey = comps[1];

    var xs = cs.map(function (r) { return +r[xKey]; });
    var ys = cs.map(function (r) { return +r[yKey]; });
    if (rec.length >= 2) {
      xs.push(+rec[0]);
      ys.push(+rec[1]);
    }
    var xScale = d3.scaleLinear().domain(paddedExtent(xs)).range([0, IW]).nice();
    var yScale = d3.scaleLinear().domain(paddedExtent(ys)).range([IH, 0]).nice();

    var chart = makeSvg(sel, {
      title: level + " confidence set",
      xlab: xKey,
      ylab: yKey,
      xScale: xScale,
      yScale: yScale
    });
    var g = chart.g;
    var tip = makeTooltip(g);

    // subtitle
    chart.svg
      .append("text")
      .attr("x", MARGIN.left)
      .attr("y", 30)
      .style("font-size", "11px")
      .style("fill", "#555")
      .text("Red diamond: recommended intervention. Hover a point for details.");

    // confidence-set points
    g.selectAll("circle.cs-pt")
      .data(cs)
      .enter()
      .append("circle")
      .attr("class", "cs-pt")
      .attr("cx", function (d) { return xScale(+d[xKey]); })
      .attr("cy", function (d) { return yScale(+d[yKey]); })
      .attr("r", 5)
      .attr("fill", COLOR_POINT)
      .attr("fill-opacity", 0.55)
      .attr("stroke", "white")
      .attr("stroke-width", 0.75)
      .style("cursor", "pointer")
      .on("mouseover", function (event, d) {
        d3.select(this).attr("fill-opacity", 1).attr("r", 6.5);
        tip.show(csTooltipLines(comps, d), xScale(+d[xKey]), yScale(+d[yKey]));
      })
      .on("mouseout", function () {
        d3.select(this).attr("fill-opacity", 0.55).attr("r", 5);
        tip.hide();
      });

    // recommended intervention (red diamond)
    if (rec.length >= 2) {
      var rx = xScale(+rec[0]);
      var ry = yScale(+rec[1]);
      g.append("path")
        .attr("d", d3.symbol().type(d3.symbolDiamond).size(150)())
        .attr("transform", "translate(" + rx + "," + ry + ")")
        .attr("fill", COLOR_REC)
        .attr("stroke", "white")
        .attr("stroke-width", 1)
        .style("cursor", "pointer")
        .on("mouseover", function () {
          var lines = [
            "recommended",
            xKey + ": " + fmtValue(rec[0]),
            yKey + ": " + fmtValue(rec[1])
          ];
          if (recCost != null && isFinite(recCost)) {
            lines.push("cost: " + fmtCost(recCost));
          }
          tip.show(lines, rx, ry);
        })
        .on("mouseout", function () {
          tip.hide();
        });
    }
  }

  function renderCsStrip(sel, comps, cs, rec, recCost) {
    var xKey = comps[0];
    var xs = cs.map(function (r) { return +r[xKey]; });
    if (rec.length >= 1) {
      xs.push(+rec[0]);
    }
    var xScale = d3.scaleLinear().domain(paddedExtent(xs)).range([0, IW]).nice();
    var yLine = IH / 2;

    var chart = makeSvg(sel, {
      title: level + " confidence set",
      xlab: xKey,
      ylab: null,
      xScale: xScale,
      yScale: null
    });
    var g = chart.g;
    var tip = makeTooltip(g);

    chart.svg
      .append("text")
      .attr("x", MARGIN.left)
      .attr("y", 30)
      .style("font-size", "11px")
      .style("fill", "#555")
      .text("Each dot is a dose in the set. Red: recommended. Hover for the CI.");

    // baseline
    g.append("line")
      .attr("x1", 0)
      .attr("x2", IW)
      .attr("y1", yLine)
      .attr("y2", yLine)
      .attr("stroke", "#ccc");

    // dose points along the line
    g.selectAll("circle.cs-pt")
      .data(cs)
      .enter()
      .append("circle")
      .attr("class", "cs-pt")
      .attr("cx", function (d) { return xScale(+d[xKey]); })
      .attr("cy", yLine)
      .attr("r", 5)
      .attr("fill", COLOR_POINT)
      .attr("fill-opacity", 0.55)
      .attr("stroke", "white")
      .attr("stroke-width", 0.75)
      .style("cursor", "pointer")
      .on("mouseover", function (event, d) {
        d3.select(this).attr("fill-opacity", 1).attr("r", 6.5);
        tip.show(csTooltipLines(comps, d), xScale(+d[xKey]), yLine);
      })
      .on("mouseout", function () {
        d3.select(this).attr("fill-opacity", 0.55).attr("r", 5);
        tip.hide();
      });

    // recommended dose (red)
    if (rec.length >= 1) {
      var rx = xScale(+rec[0]);
      g.append("circle")
        .attr("cx", rx)
        .attr("cy", yLine)
        .attr("r", 7)
        .attr("fill", COLOR_REC)
        .attr("stroke", "white")
        .attr("stroke-width", 1.5)
        .style("cursor", "pointer")
        .on("mouseover", function () {
          var lines = ["recommended", xKey + ": " + fmtValue(rec[0])];
          if (recCost != null && isFinite(recCost)) {
            lines.push("cost: " + fmtCost(recCost));
          }
          tip.show(lines, rx, yLine);
        })
        .on("mouseout", function () {
          tip.hide();
        });
    }
  }

  // ---- cost-curve viz -----------------------------------------------------
  //
  // data.cost.components : one name per intervention component.
  // data.cost.coefs      : one polynomial-coefficient vector per component
  //                        (matches lago_optimization()'s cost_list_of_vectors).
  // data.cost.lb / .ub   : lower / upper bound per component.
  //
  // For each component two curves are drawn: total cost and marginal cost,
  // each with a hover read-out. Mirrors the visuals of cost-curves.js but is
  // static (no sliders / drag): the report shows the cost functions the
  // optimization actually used.
  function renderCostCurves(elementId, data) {
    var host = document.getElementById(elementId);
    if (!host || !data || !data.cost || !data.cost.coefs) {
      return;
    }
    var cost = data.cost;
    var comps = cost.components || [];
    var sel = d3.select(host);
    sel.selectAll("*").remove();

    cost.coefs.forEach(function (coefs, i) {
      var name = comps[i] != null ? comps[i] : "Component " + (i + 1);
      var lb = +cost.lb[i];
      var ub = +cost.ub[i];
      if (!isFinite(lb) || !isFinite(ub) || !(ub > lb)) {
        return; // skip a degenerate range instead of drawing garbage
      }
      var block = sel
        .append("div")
        .style("margin-bottom", "18px")
        .style("border-top", i === 0 ? "none" : "1px solid #eee")
        .style("padding-top", i === 0 ? "0" : "10px");
      costCurveChart(block, coefs, lb, ub, name, "total");
      costCurveChart(block, coefs, lb, ub, name, "marginal");
    });
  }

  // Draw one cost curve ("total" or "marginal") for a component into `sel`.
  function costCurveChart(sel, coefs, lb, ub, name, kind) {
    var isTotal = kind === "total";
    // sampleCurve calls fn(coefs, x), so pass the two-argument math function
    // itself; valueAt is the one-argument form used by the hover read-out.
    var curveFn = isTotal ? costAt : marginalAt;
    var valueAt = function (x) { return curveFn(coefs, x); };
    var color = isTotal ? COLOR_TOTAL : COLOR_MARGINAL;
    var ylab = isTotal ? "Total cost" : "Marginal cost";
    var title = (isTotal ? "Total cost - " : "Marginal cost - ") + name;

    var pts = sampleCurve(coefs, lb, ub, 200, curveFn);
    var ys = pts.map(function (p) { return p.y; });
    // always include 0 so a flat/zero curve and the baseline stay visible
    var yLo = Math.min(0, d3.min(ys));
    var yHi = d3.max(ys);
    if (!(yHi > yLo)) {
      yHi = yLo + 1;
    }
    var yPad = (yHi - yLo) * 0.12;

    var xScale = d3.scaleLinear().domain([lb, ub]).range([0, IW]);
    var yScale = d3
      .scaleLinear()
      .domain([yLo - (yLo < 0 ? yPad : 0), yHi + yPad])
      .range([IH, 0]);

    var chart = makeSvg(sel, {
      title: title,
      xlab: name,
      ylab: ylab,
      xScale: xScale,
      yScale: yScale
    });
    var g = chart.g;

    var lineGen = d3
      .line()
      .x(function (p) { return xScale(p.x); })
      .y(function (p) { return yScale(p.y); });

    g.append("path")
      .datum(pts)
      .attr("fill", "none")
      .attr("stroke", color)
      .attr("stroke-width", 2)
      .attr("d", lineGen);

    // hover: vertical guide + dot + tooltip, reading the exact curve value.
    var tip = makeTooltip(g);
    var focus = g.append("g").style("display", "none");
    var guide = focus
      .append("line")
      .attr("y1", 0)
      .attr("y2", IH)
      .attr("stroke", "#888")
      .attr("stroke-dasharray", "3,3");
    var dot = focus
      .append("circle")
      .attr("r", 4)
      .attr("fill", color)
      .attr("stroke", "white")
      .attr("stroke-width", 1.5);

    g.append("rect")
      .attr("width", IW)
      .attr("height", IH)
      .attr("fill", "none")
      .attr("pointer-events", "all")
      .on("mouseover", function () {
        focus.style("display", null);
      })
      .on("mouseout", function () {
        focus.style("display", "none");
        tip.hide();
      })
      .on("mousemove touchmove", function (event) {
        var mx = d3.pointer(event, this)[0];
        var xv = Math.max(lb, Math.min(ub, xScale.invert(mx)));
        var yv = valueAt(xv);
        var px = xScale(xv);
        var py = yScale(yv);
        guide.attr("x1", px).attr("x2", px);
        dot.attr("cx", px).attr("cy", py);
        tip.show([name + ": " + fmtValue(xv), ylab + ": " + fmtCost(yv)], px, py);
      });
  }

  // ---- sensitivity viz ----------------------------------------------------
  //
  // data.parameter  : the swept parameter name, used as the x-axis label
  //                   (e.g. "outcome_goal" or "cost_multiplier").
  // data.points     : array of { value, cost, est, status, shrunk, comps },
  //                   one per swept value; comps is an object of component
  //                   name -> recommended value for that run (shown in the
  //                   tooltip), and shrunk is whether the run used the
  //                   shrinking method.
  // data.components : component names, giving the tooltip a stable order.
  // data.intention  : "maximize" or "minimize", the direction of the goal.
  //
  // Draws the recommended cost against the swept value as a line with points:
  // a cost-of-stringency curve for an outcome_goal sweep, a straight line for a
  // cost_multiplier sweep. Points with a non-finite cost (a failed run) are
  // dropped; a no-op when none remain.
  function renderSensitivity(elementId, data) {
    var host = document.getElementById(elementId);
    if (!host || !data || !data.points) {
      return;
    }
    var comps = data.components || [];
    var pts = sensFinitePoints(data.points);
    var sel = d3.select(host);
    sel.selectAll("*").remove();
    if (pts.length === 0) {
      return;
    }

    var xs = pts.map(function (p) { return +p.value; });
    var ys = pts.map(function (p) { return +p.cost; });
    var xScale = d3.scaleLinear().domain(paddedExtent(xs)).range([0, IW]).nice();
    // anchor the cost axis at 0 so a flat curve stays readable
    var yLo = Math.min(0, d3.min(ys));
    var yHi = d3.max(ys);
    if (!(yHi > yLo)) {
      yHi = yLo + 1;
    }
    var yScale = d3
      .scaleLinear()
      .domain([yLo, yHi + (yHi - yLo) * 0.1])
      .range([IH, 0])
      .nice();

    var chart = makeSvg(sel, {
      title: "Sensitivity: recommended cost",
      xlab: data.parameter,
      ylab: "recommended cost",
      xScale: xScale,
      yScale: yScale
    });
    var g = chart.g;
    var tip = makeTooltip(g);

    // sort by x so the connecting line runs monotone in the swept value
    var line = pts.slice().sort(function (a, b) { return +a.value - +b.value; });
    var lineGen = d3
      .line()
      .x(function (p) { return xScale(+p.value); })
      .y(function (p) { return yScale(+p.cost); });
    g.append("path")
      .datum(line)
      .attr("fill", "none")
      .attr("stroke", COLOR_TOTAL)
      .attr("stroke-width", 2)
      .attr("d", lineGen);

    g.selectAll("circle.sens-pt")
      .data(pts)
      .enter()
      .append("circle")
      .attr("class", "sens-pt")
      .attr("cx", function (d) { return xScale(+d.value); })
      .attr("cy", function (d) { return yScale(+d.cost); })
      .attr("r", 5)
      .attr("fill", COLOR_TOTAL)
      .attr("fill-opacity", 0.7)
      .attr("stroke", "white")
      .attr("stroke-width", 0.75)
      .style("cursor", "pointer")
      .on("mouseover", function (event, d) {
        d3.select(this).attr("fill-opacity", 1).attr("r", 6.5);
        tip.show(sensTooltipLines(comps, data.parameter, d, data.intention), xScale(+d.value), yScale(+d.cost));
      })
      .on("mouseout", function () {
        d3.select(this).attr("fill-opacity", 0.7).attr("r", 5);
        tip.hide();
      });
  }

  // Tooltip lines for one sensitivity point: the swept value, the cost, the
  // estimated outcome, then each component's recommended value. An outcome
  // goal and the estimated outcome are rounded with fmtInterval(), as R's
  // print() rounds them, so an estimate that meets its goal never shows
  // below it and a goal closer to 0 than 1e-6 does not show as 0.
  // In an outcome goal sweep the estimate of a run that reached its goal
  // (p.shrunk false) uses fmtEstimate(), so it never shows on the missed side
  // of the goal shown above it, for the goal direction intention.
  function sensTooltipLines(comps, param, p, intention) {
    var goalSweep = param === "outcome_goal";
    var fmtParam = goalSweep ? fmtInterval : fmtValue;
    var lines = [param + ": " + fmtParam(p.value), "cost: " + fmtCost(p.cost)];
    if (p.est != null && isFinite(+p.est)) {
      lines.push("est. outcome: " + (goalSweep ? fmtEstimate(p.est, p.value, intention, p.shrunk === false) : fmtInterval(p.est)));
    }
    (comps || []).forEach(function (c) {
      if (p.comps && p.comps[c] != null && isFinite(+p.comps[c])) {
        lines.push(c + ": " + fmtValue(p.comps[c]));
      }
    });
    return lines;
  }

  // ---- budget-frontier viz ------------------------------------------------
  //
  // data.frontier    : array of { outcome_goal, rec_int_cost, est_outcome,
  //                    affordable, status }, the reachable cost/outcome tradeoff.
  // data.budget      : the cost budget (drawn as a vertical line).
  // data.feasible    : whether a within-budget recommendation was found.
  // data.cost/.est_outcome : the chosen point (highlighted) when feasible.
  //
  // Plots estimated outcome against recommended cost (the cost-effectiveness
  // frontier), colours points within/over budget, marks the budget with a
  // dashed line, and highlights the chosen recommendation. Mirrors
  // plot.lago_budget(). No-op when nothing reachable is finite.
  function renderBudget(elementId, data) {
    var host = document.getElementById(elementId);
    if (!host || !data || !data.frontier) {
      return;
    }
    var pts = budgetFinitePoints(data.frontier);
    var sel = d3.select(host);
    sel.selectAll("*").remove();
    if (pts.length === 0) {
      return;
    }

    var xs = pts.map(function (p) { return +p.rec_int_cost; });
    var ys = pts.map(function (p) { return +p.est_outcome; });
    if (data.budget != null && isFinite(+data.budget)) xs.push(+data.budget);
    var xScale = d3.scaleLinear().domain(paddedExtent(xs)).range([0, IW]).nice();
    var yScale = d3.scaleLinear().domain(paddedExtent(ys)).range([IH, 0]).nice();

    var chart = makeSvg(sel, {
      title: "Budget frontier: best outcome per cost",
      xlab: "recommended cost",
      ylab: "estimated outcome",
      xScale: xScale,
      yScale: yScale
    });
    var g = chart.g;
    var tip = makeTooltip(g);

    // connecting line, in cost order
    var line = pts.slice().sort(function (a, b) {
      return +a.rec_int_cost - +b.rec_int_cost;
    });
    g.append("path")
      .datum(line)
      .attr("fill", "none")
      .attr("stroke", COLOR_TOTAL)
      .attr("stroke-width", 2)
      .attr("d", d3.line()
        .x(function (p) { return xScale(+p.rec_int_cost); })
        .y(function (p) { return yScale(+p.est_outcome); }));

    // budget line
    if (data.budget != null && isFinite(+data.budget)) {
      var bx = xScale(+data.budget);
      g.append("line")
        .attr("x1", bx).attr("x2", bx).attr("y1", 0).attr("y2", IH)
        .attr("stroke", COLOR_REC).attr("stroke-dasharray", "4,3");
    }

    // points, coloured by affordability
    g.selectAll("circle.bud-pt")
      .data(pts)
      .enter()
      .append("circle")
      .attr("class", "bud-pt")
      .attr("cx", function (d) { return xScale(+d.rec_int_cost); })
      .attr("cy", function (d) { return yScale(+d.est_outcome); })
      .attr("r", 5)
      .attr("fill", function (d) { return d.affordable ? COLOR_POINT : "#b0b7c0"; })
      .attr("fill-opacity", 0.75)
      .attr("stroke", "white")
      .attr("stroke-width", 0.75)
      .style("cursor", "pointer")
      .on("mouseover", function (event, d) {
        d3.select(this).attr("fill-opacity", 1).attr("r", 6.5);
        tip.show([
          "cost: " + fmtCostWithin(d.rec_int_cost, data.budget),
          "est. outcome: " + fmtInterval(d.est_outcome),
          d.affordable ? "within budget" : "over budget"
        ], xScale(+d.rec_int_cost), yScale(+d.est_outcome));
      })
      .on("mouseout", function () {
        d3.select(this).attr("fill-opacity", 0.75).attr("r", 5);
        tip.hide();
      });

    // chosen recommendation (red diamond)
    if (data.feasible && data.cost != null && isFinite(+data.cost) &&
      data.est_outcome != null && isFinite(+data.est_outcome)) {
      g.append("path")
        .attr("d", d3.symbol().type(d3.symbolDiamond).size(120))
        .attr("transform", "translate(" + xScale(+data.cost) + "," +
          yScale(+data.est_outcome) + ")")
        .attr("fill", COLOR_REC)
        .attr("stroke", "white")
        .attr("stroke-width", 1.5);
    }
  }

  // Public API.
  if (global) {
    global.LAGOReport = {
      renderConfidenceSet: renderConfidenceSet,
      renderCostCurves: renderCostCurves,
      renderSensitivity: renderSensitivity,
      renderBudget: renderBudget
    };
  }
})(typeof window !== "undefined" ? window : this);
